

	
       var app= angular.module('myapp', ['ngMaterial', 'ngStorage']);
        app.controller("myctrl",
            
                function($http, $scope, myFactory, $log, $window, $localStorage, $filter) {


                    $scope.MovieData = [];
                    $scope.Search = null;
                   
                    $scope.GetMoviesData = function() {
                        try {

                           
                            $http({
                                url: 'http://www.omdbapi.com/?apikey=81d3b711&s='+$scope.Search,
                                method: "GET",
                            }).then(
                                function(loadedData) {
                                    $scope.MovieData = loadedData.data;
                                 //storing data in localstorage
                                     $localStorage.myKey.push =  loadedData.data;
                                     $scope.restored_data = $localStorage.myKey;

                                 /////////////////////////////////////////   
                                },
                                function(){
                                alert("Something is wrong. Please try again.");
                                });
                        } catch (error) {
                            alert("Exception occured while fetching movie data.");
                        }
                    }
                    ///////////////////////////////////////

                    //service called here
                    myFactory.setMessage("Hello, I'm From Factory ");
                    $scope.factoryMsg = myFactory.message;


            });

//service declared here
app.factory('myFactory', function () {
    var obj = {};
    obj.message = '';
    obj.setMessage = function (newMessage) {
        obj.message = newMessage;
    };
    return obj;
});
